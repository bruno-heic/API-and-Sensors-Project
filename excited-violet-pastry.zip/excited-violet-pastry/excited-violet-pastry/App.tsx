import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useFonts, GoogleSans_400Regular, GoogleSans_500Medium, GoogleSans_600SemiBold, GoogleSans_700Bold } from '@expo-google-fonts/google-sans';
import { View, ActivityIndicator } from 'react-native';
import { Ionicons, FontAwesome, AntDesign } from '@expo/vector-icons';

import HomeScreen from './(tabs)/HomeScreen';
import AboutScreen from './(tabs)/AboutScreen';

import { BarometerProvider } from './hooks/Barometer';

const Tab = createBottomTabNavigator();

export default function App() {
  let [fontsLoaded] = useFonts({
    GoogleSans_400Regular,
    GoogleSans_500Medium,
    GoogleSans_600SemiBold,
    GoogleSans_700Bold
  });

  if (!fontsLoaded) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#001d35" />
      </View>
    );
  }

  return (
    <BarometerProvider>
      <NavigationContainer>
        <Tab.Navigator
          initialRouteName="Home"
          screenOptions={{
            // Ajustes na barra para acomodar perfeitamente os ícones e rótulos
            tabBarStyle: {
              height: 100, 
              backgroundColor: '#f8fafd', 
              borderTopWidth: 0,
              elevation: 5, 
              shadowColor: '#000', 
              shadowOffset: { width: 0, height: -2 },
              shadowOpacity: 0.05,
              shadowRadius: 3,
              paddingBottom: 12, // Dá espaço confortável para o texto na base
              paddingTop: 12,    // Alinha a área dos ícones no topo
            },
            headerShown: false,
            tabBarActiveTintColor: '#001d35',   
            tabBarInactiveTintColor: '#43474e', 
            tabBarLabelStyle: {
              fontSize: 12,
              fontFamily: 'GoogleSans_600SemiBold', // Um pouco mais forte para leitura no escuro/claro
              marginTop: 4,
            },
            // Centraliza o bloco de ícone + label horizontalmente
            tabBarIconStyle: {
              marginBottom: 4, 
            }
          }}
        >
          <Tab.Screen
            name="Home"
            component={HomeScreen}
            options={{
              tabBarLabel: 'Mapa',
              tabBarIcon: ({ focused, color }) => (
                <View style={{
                  backgroundColor: focused ? '#c2e7ff' : 'transparent',
                  width: 64,
                  height: 32,
                  borderRadius: 16,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  <FontAwesome 
                    name={'map-pin'} 
                    size={22} 
                    color={focused ? '#001d35' : color} // Garante a cor correta de contraste dentro da pílula
                  />
                </View>
              ),
            }}
          />

          <Tab.Screen
            name="Profile"
            component={AboutScreen}
            options={{
              tabBarLabel: 'Sobre',
              tabBarIcon: ({ focused, color }) => (
                <View style={{
                  backgroundColor: focused ? '#c2e7ff' : 'transparent',
                  width: 64,
                  height: 32,
                  borderRadius: 16,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  <AntDesign 
                    name={"info-circle"} 
                    size={22} 
                    color={focused ? '#001d35' : color} 
                  />
                </View>
              ),
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </BarometerProvider>
  );
}