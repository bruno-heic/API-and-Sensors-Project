import React, { createContext, useState, useEffect, useContext } from 'react';
import { Barometer } from 'expo-sensors';

const BarometerContext = createContext();

export function BarometerProvider({ children }) {
  const [data, setData] = useState({ pressure: 0, relativeAltitude: 0 });

  useEffect(() => {

    Barometer.setUpdateInterval(100); 

    const subscription = Barometer.addListener((barometerData) => {
      setData(barometerData);
    });

    return () => {
      subscription.remove();
    };
  }, []);

  return (
    <BarometerContext.Provider value={data}>
      {children}
    </BarometerContext.Provider>
  );
}

export function useGlobalBarometer() {
  return useContext(BarometerContext);
}