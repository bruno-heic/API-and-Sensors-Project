import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, ScrollView, SafeAreaView, Platform, Dimensions, TouchableOpacity } from 'react-native';
import { FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import { Barometer } from 'expo-sensors';

const { width } = Dimensions.get('window');

export default function AboutScreen() {
  const [pressure, setPressure] = useState(null);
  const [barometerAvailable, setBarometerAvailable] = useState(true);
  const [subscription, setSubscription] = useState(null);

  useEffect(() => {
    _subscribe();
    return () => _unsubscribe();
  }, []);

  const _subscribe = async () => {
    const isAvailable = await Barometer.isAvailableAsync();
    setBarometerAvailable(isAvailable);

    if (isAvailable) {
      Barometer.setUpdateInterval(1000);
      const sub = Barometer.addListener(barometerData => {
        setPressure(barometerData.pressure);
      });
      setSubscription(sub);
    }
  };

  const _unsubscribe = () => {
    subscription && subscription.remove();
    setSubscription(null);
  };

  const calculateApproxAltitude = (p) => {
    if (!p) return 0;
    return Math.round(44330 * (1 - Math.pow(p / 1013.25, 1 / 5.255)));
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        
        {/* Header inspirado na UI Clean do Google */}
        <View style={styles.header}>
          <View style={styles.titleRow}>
            <Text style={styles.brandTitle}>
              <Text style={{ color: '#4285F4' }}>G</Text>
              <Text style={{ color: '#EA4335' }}>o</Text>
              <Text style={{ color: '#FBBC05' }}>o</Text>
              <Text style={{ color: '#4285F4' }}>g</Text>
              <Text style={{ color: '#34A853' }}>l</Text>
              <Text style={{ color: '#EA4335' }}>e</Text>
              <Text style={styles.subTitle}> ATM</Text>
            </Text>
            <View style={styles.badgeContainer}>
              <Text style={styles.badgeAlpha}>Alpha</Text>
            </View>
          </View>
          <Text style={styles.tagline}>Exploração Urbana & Dinâmicas Atmosféricas</Text>
        </View>

        {/* Card do Hardware: Barômetro em Tempo Real */}
        <View style={styles.hardwareCard}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="gauge" size={20} color="#1a73e8" />
            <Text style={styles.cardMainTitle}>Sensor de Pressão Local</Text>
          </View>
          
          {barometerAvailable ? (
            <View style={styles.barometerContent}>
              <View style={styles.dataRow}>
                <View style={styles.dataItem}>
                  <Text style={styles.dataLabel}>Pressão do Ar</Text>
                  <Text style={styles.dataValue}>
                    {pressure ? `${pressure.toFixed(1)}` : 'Lendo...'} <Text style={styles.unit}>hPa</Text>
                  </Text>
                </View>
                <View style={styles.verticalDivider} />
                <View style={styles.dataItem}>
                  <Text style={styles.dataLabel}>Altímetro Relativo</Text>
                  <Text style={styles.dataValue}>
                    {pressure ? `~${calculateApproxAltitude(pressure)}` : 'Lendo...'} <Text style={styles.unit}>m</Text>
                  </Text>
                </View>
              </View>
              <Text style={styles.sensorNote}>*Dados obtidos diretamente do barômetro interno do seu dispositivo.</Text>
            </View>
          ) : (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>Barômetro não detectado neste aparelho. Exibindo dados simulados de referência estável.</Text>
              <Text style={styles.dataValue}>1013.2 <Text style={styles.unit}>hPa</Text></Text>
            </View>
          )}
        </View>

        {/* Seção de Funcionalidades e Pilares do App */}
        <Text style={styles.sectionTitle}>Sobre o Projeto</Text>

        {/* Item 1: UI Inspirada */}
        <View style={styles.featureRow}>
          <View style={[styles.iconWrapper, { backgroundColor: '#e8f0fe' }]}>
            <FontAwesome5 name="google" size={16} color="#1a73e8" />
          </View>
          <View style={styles.featureTextContainer}>
            <Text style={styles.featureTitle}>DNA Visual do Google</Text>
            <Text style={styles.featureDescription}>
              Interface minimalista baseada nas diretrizes do Material Design. Cores balanceadas, cantos arredondados, tipografia limpa e cards flutuantes que priorizam a informação essencial.
            </Text>
          </View>
        </View>

        {/* Item 2: Mapa 3D */}
        <View style={styles.featureRow}>
          <View style={[styles.iconWrapper, { backgroundColor: '#feeee7' }]}>
            <FontAwesome5 name="layer-group" size={14} color="#ea4335" />
          </View>
          <View style={styles.featureTextContainer}>
            <Text style={styles.featureTitle}>Projeção Urbana em 3D</Text>
            <Text style={styles.featureDescription}>
              Renderização de malhas de edifícios volumétricos em tempo real utilizando vetores abertos. O mapa ganha profundidade com controle dinâmico de inclinação (*pitch*) e rotação.
            </Text>
          </View>
        </View>

        {/* Item 3: Clima Avançado */}
        <View style={styles.featureRow}>
          <View style={[styles.iconWrapper, { backgroundColor: '#fef7e0' }]}>
            <FontAwesome5 name="cloud-sun" size={14} color="#fbbc05" />
          </View>
          <View style={styles.featureTextContainer}>
            <Text style={styles.featureTitle}>Análise Bioclimática</Text>
            <Text style={styles.featureDescription}>
              Cruza variáveis de temperatura, umidade e códigos WMO para gerar relatórios inteligentes de bem-estar, avaliando o ambiente para atividades externas.
            </Text>
          </View>
        </View>
        <View style={styles.footer}>
          <Text style={styles.footerText}>Google ATM v0.1.4-alpha</Text>
          <Text style={styles.footerSubText}>Desenvolvido para fins de estudo de geoprocessamento e integração de hardware no ecossistema mobile.</Text>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  scrollContainer: {
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 20 : 40,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 36,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandTitle: {
    fontSize: 28,
    fontWeight: 'normal',
    fontFamily: Platform.OS === 'android' ? 'sans-serif-medium' : 'System',
    letterSpacing: -0.5,
  },
  subTitle: {
    color: '#5f6368',
    fontWeight: 'normal',
    fontFamily: "GoogleSans_500Medium",
  },
  badgeContainer: {
    marginLeft: 8,
    backgroundColor: '#e8f0fe',
    borderRadius: 50, // Garante formato de pílula esférica
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: '#d2e3fc',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeAlpha: {
    fontSize: 11,
    color: '#1a73e8',
    fontWeight: '600',
    fontFamily: "GoogleSans_500Medium",
  },
  tagline: {
    fontSize: 13,
    color: '#70757a',
    marginTop: 10,
    textAlign: 'center',
    fontFamily: "GoogleSans_400Regular",
  },
  hardwareCard: {
    backgroundColor: '#ffffff',
    borderRadius: 20, // Cantos mais suaves seguindo a nova UI do Google
    padding: 20,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 1,
    marginBottom: 36,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  cardMainTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#202124',
    marginLeft: 10,
    fontFamily: "GoogleSans_500Medium",
  },
  barometerContent: {
    alignItems: 'center',
  },
  dataRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  dataItem: {
    alignItems: 'center',
    flex: 1,
  },
  dataLabel: {
    fontSize: 11,
    color: '#70757a',
    textTransform: 'uppercase',
    fontWeight: '500',
    marginBottom: 6,
    letterSpacing: 0.5,
    fontFamily: "GoogleSans_500Medium",
  },
  dataValue: {
    fontSize: 28,
    fontWeight: '300',
    color: '#202124',
    fontFamily: "GoogleSans_400Regular"
  },
  unit: {
    fontSize: 14,
    color: '#5f6368',
    fontWeight: 'normal',
  },
  verticalDivider: {
    width: 1,
    height: 44,
    backgroundColor: '#eee',
    alignSelf: 'center',
  },
  sensorNote: {
    fontSize: 10,
    color: '#9aa0a6',
    marginTop: 16,
    textAlign: 'center',
    fontFamily: "GoogleSans_400Regular"
  },
  errorBox: {
    alignItems: 'center',
    paddingVertical: 8,
  },
  errorText: {
    fontSize: 12,
    color: '#ea4335',
    textAlign: 'center',
    marginBottom: 10,
    lineHeight: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#202124',
    marginBottom: 22,
    letterSpacing: -0.3,
    fontFamily: "GoogleSans_500Medium",
  },
  featureRow: {
    flexDirection: 'row',
    marginBottom: 26,
    alignItems: 'flex-start',
  },
  iconWrapper: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
    marginTop: 2,
  },
  featureTextContainer: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#3c4043',
    marginBottom: 6,
    fontFamily: "GoogleSans_500Medium",
  },
  featureDescription: {
    fontSize: 13,
    color: '#5f6368',
    lineHeight: 19,
    fontFamily: "GoogleSans_400Regular"
  },
  footer: {
    marginTop: 24,
    paddingTop: 24,
    borderTopWidth: 1,
    borderTopColor: '#f1f3f4',
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#3c4043',
    marginBottom: 4,
    fontFamily: "GoogleSans_500Medium",
  },
  footerSubText: {
    fontSize: 11,
    color: '#9aa0a6',
    textAlign: 'center',
    lineHeight: 16,
    fontFamily: "GoogleSans_400Regular"
  },
});