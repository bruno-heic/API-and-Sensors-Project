import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, View, TextInput, SafeAreaView, Platform, FlatList, Text, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import { FontAwesome5 } from '@expo/vector-icons'; 

import * as Location from 'expo-location'; 

export default function HomeScreen() {
  
  const longitude = -74.0066;
  const latitude = 40.7135;

  const webViewRef = useRef(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  const [selectedPlace, setSelectedPlace] = useState(null);
  const [loadingWeather, setLoadingWeather] = useState(false);

  
  const fetchSuggestions = async (text) => {
    if (text.length < 3) {
      setSuggestions([]);
      return;
    }

    setLoading(true);
    try {
      const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(text)}&limit=5&addressdetails=1`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': 'MeuAppMapasExploracao/1.0',
        },
      });

      const data = await response.json();
      setSuggestions(data);
    } catch (error) {
      console.error("Erro ao buscar dados no Nominatim:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchWeather = async (lat, lon, displayName) => {
    setLoadingWeather(true);
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,surface_pressure,weather_code&timezone=auto`;
      
      const response = await fetch(url);
      const data = await response.json();

      if (data && data.current) {
        setSelectedPlace({
          name: displayName,
          temp: data.current.temperature_2m,
          humidity: data.current.relative_humidity_2m,
          pressure: data.current.surface_pressure,
          weatherCode: data.current.weather_code,
          lat: lat,
          lon: lon
        });
      }
    } catch (error) {
      console.error("Erro ao buscar dados no Open-Meteo:", error);
    } finally {
      setLoadingWeather(false);
    }
  };

  const getWeatherDescription = (code) => {
    if (code === 0) return 'Céu Limpo';
    if (code >= 1 && code <= 3) return 'Parcialmente Nublado';
    if (code >= 45 && code <= 48) return 'Nevoeiro';
    if (code >= 51 && code <= 67) return 'Chuva Leve';
    if (code >= 71 && code <= 77) return 'Neve';
    if (code >= 80 && code <= 82) return 'Pancadas de Chuva';
    if (code >= 95 && code <= 99) return 'Trovoada';
    return 'Instável';
  };

  const getWeatherAnalysis = (temp, humidity, code) => {
    if (code >= 80) {
      return { status: 'Ruim', color: '#ea4335', desc: 'Evite atividades ao ar livre devido à chuva/tempestade ativa.' };
    }
    if (temp > 35 || temp < 10) {
      return { status: 'Desconfortável', color: '#fbbc05', desc: 'Temperatura em extremo. Agasalhe-se ou mantenha-se hidratado.' };
    }
    if (humidity < 30) {
      return { status: 'Moderado', color: '#fbbc05', desc: 'Ar muito seco. Condição de alerta para exercícios físicos.' };
    }
    if (temp >= 18 && temp <= 26 && humidity >= 40 && humidity <= 70 && code <= 3) {
      return { status: 'Excelente', color: '#34a853', desc: 'Clima perfeito para passeios, caminhadas e atividades externas!' };
    }
    return { status: 'Bom', color: '#1a73e8', desc: 'Tempo estável na região. Condições confortáveis para o dia a dia.' };
  };

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      fetchSuggestions(searchQuery);
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  const moveMapToCoordinates = (lat, lon) => {
    if (webViewRef.current) {
      const jsCode = `
        if (window.map) {
          window.map.flyTo({
            center: [${lon}, ${lat}],
            zoom: 16,
            pitch: 45,
            essential: true,
            speed: 1.5 
          });
        }
        true;
      `;
      webViewRef.current.injectJavaScript(jsCode);
    }
  };

  const handleSelectSuggestion = (item) => {
    setSuggestions([]); 
    setSearchQuery(''); 
    const lat = parseFloat(item.lat);
    const lon = parseFloat(item.lon);

    moveMapToCoordinates(lat, lon);
    fetchWeather(lat, lon, item.display_name);
  };

  const handleMyLocationPress = async () => {
    setLoadingWeather(true);
    try {
      let { status } = await Location.requestForegroundPermissionsAsync();
      
      if (status !== 'granted') {
        Alert.alert(
          "Permissão Negada", 
          "Precisamos do acesso à localização para mostrar o clima onde você está.",
          [{ text: "OK" }]
        );
        setLoadingWeather(false);
        return;
      }
      let location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const myLat = location.coords.latitude;
      const myLon = location.coords.longitude;
      moveMapToCoordinates(myLat, myLon);
      fetchWeather(myLat, myLon, "Sua Localização Atual");

    } catch (error) {
      console.error("Erro ao obter localização nativa:", error);
      Alert.alert("Erro", "Não foi possível obter sua localização atual.");
      setLoadingWeather(false);
    }
  };

  const htmlMap = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8" />
        <title>MapLibre OpenFreeMap 3D</title>
        <meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no" />
        <script src="https://unpkg.com/maplibre-gl@3.6.2/dist/maplibre-gl.js"></script>
        <link href="https://unpkg.com/maplibre-gl@3.6.2/dist/maplibre-gl.css" rel="stylesheet" />
        <style>
            body { margin: 0; padding: 0; }
            #map { position: absolute; top: 0; bottom: 0; width: 100%; }
            .maplibregl-ctrl-attrib { display: none !important; }
        </style>
    </head>
    <body>
        <div id="map"></div>
      <script>
        window.map = new maplibregl.Map({
          container: 'map',
          style: 'https://tiles.openfreemap.org/styles/bright',
          center: [${longitude}, ${latitude}],
          zoom: 15.5,
          pitch: 45,
          bearing: -17.6,
          canvasContextAttributes: { antialias: true }
        });

        window.map.on('load', () => {
            const layers = window.map.getStyle().layers;
            let labelLayerId;
            for (let i = 0; i < layers.length; i++) {
                if (layers[i].type === 'symbol' && layers[i].layout['text-field']) {
                    labelLayerId = layers[i].id;
                    break;
                }
            }

            window.map.addSource('openfreemap', {
                url: 'https://tiles.openfreemap.org/planet',
                type: 'vector',
            });

            window.map.addLayer(
                {
                    'id': '3d-buildings',
                    'source': 'openfreemap',
                    'source-layer': 'building',
                    'type': 'fill-extrusion',
                    'minzoom': 15,
                    'filter': ['!=', ['get', 'hide_3d'], true],
                    'paint': {
                        'fill-extrusion-color': [
                            'interpolate',
                            ['linear'],
                            ['get', 'render_height'], 0, 'lightgray', 200, 'royalblue', 400, 'lightblue'
                        ],
                        'fill-extrusion-height': [
                            'interpolate',
                            ['linear'],
                            ['zoom'],
                            15, 0,
                            16, ['get', 'render_height']
                        ],
                        'fill-extrusion-base': ['case',
                            ['>=', ['get', 'zoom'], 16],
                            ['get', 'render_min_height'], 0
                        ]
                    }
                },
                labelLayerId
            );
        });
      </script>
    </body>
    </html>
  `;

  const weatherAnalysis = selectedPlace 
    ? getWeatherAnalysis(selectedPlace.temp, selectedPlace.humidity, selectedPlace.weatherCode)
    : null;

  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef}
        originWhitelist={['*']}
        source={{ html: htmlMap }}
        style={styles.map}
        javaScriptEnabled={true}
        domStorageEnabled={true}
      />
      
      {/* Container de pesquisa */}
      <SafeAreaView style={styles.inputContainer}>
        <View style={styles.searchRow}>
          <View style={styles.inputWrapper}>
            <TextInput 
              style={styles.input} 
              placeholder={selectedPlace ? `Atual: ${selectedPlace.name.split(',')[0]}` : "Buscar local..."}
              placeholderTextColor="#757575"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
            {loading && <ActivityIndicator style={styles.loader} color="#000" />}
          </View>

          <TouchableOpacity 
            style={styles.locationButton} 
            onPress={handleMyLocationPress}
            activeOpacity={0.8}
          >
            <FontAwesome5 name="location-arrow" size={18} color="#1a73e8" />
          </TouchableOpacity>
        </View>

        {/* Lista de sugestões */}
        {suggestions.length > 0 && (
          <View style={styles.suggestionsContainer}>
            <FlatList
              data={suggestions}
              keyExtractor={(item) => item.place_id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity 
                  style={styles.suggestionItem}
                  onPress={() => handleSelectSuggestion(item)}
                >
                  <Text numberOfLines={2} style={styles.suggestionText}>
                    {item.display_name}
                  </Text>
                </TouchableOpacity>
              )}
            />
          </View>
        )}
      </SafeAreaView>

      {/* Card de Carregamento */}
      {loadingWeather && (
        <View style={styles.weatherCard}>
          <View style={styles.dragHandle} />
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="small" color="#1a73e8" />
            <Text style={styles.loadingText}>Analisando condições...</Text>
          </View>
        </View>
      )}

      {/* Card Principal */}
      {!loadingWeather && selectedPlace && weatherAnalysis && (
        <View style={styles.weatherCard}>
          <View style={styles.dragHandle} />

          <View style={styles.cardHeader}>
            <View style={styles.headerTextContainer}>
              <Text style={styles.placeName} numberOfLines={1}>
                {selectedPlace.name.split(',')[0]}
              </Text>
              <Text style={styles.placeSubName} numberOfLines={1}>
                {selectedPlace.name.split(',').slice(1).join(',').trim() || 'Região Selecionada'}
              </Text>
            </View>
            <TouchableOpacity onPress={() => setSelectedPlace(null)} style={styles.closeButton}>
              <Text style={styles.closeButtonText}>✕</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.divider} />

          {/* Área Climatológica */}
          <View style={styles.mainWeatherSection}>
            <View style={styles.tempContainer}>
              <Text style={styles.mainTemp}>{Math.round(selectedPlace.temp)}°</Text>
              <View style={styles.weatherMeta}>
                <Text style={styles.weatherCondition}>
                  {getWeatherDescription(selectedPlace.weatherCode)}
                </Text>
                <Text style={styles.weatherSubInfo}>Tempo Real</Text>
              </View>
            </View>
            
            <View style={[styles.statusBadge, { backgroundColor: weatherAnalysis.color }]}>
              <Text style={styles.statusBadgeText}>{weatherAnalysis.status}</Text>
            </View>
          </View>

          {/* Insights climáticos */}
          <View style={styles.insightBox}>
            <Text style={styles.insightTitle}>Análise do Ambiente:</Text>
            <Text style={styles.insightText}>{weatherAnalysis.desc}</Text>
          </View>

          {/* Grid de detalhes */}
          <View style={styles.weatherGrid}>
            <View style={styles.gridItem}>
              <Text style={styles.gridLabel}>Temperatura</Text>
              <Text style={styles.gridValue}>{selectedPlace.temp}°C</Text>
            </View>

            <View style={styles.verticalDivider} />

            <View style={styles.gridItem}>
              <Text style={styles.gridLabel}>Pressão</Text>
              <Text style={styles.gridValue}>{selectedPlace.pressure} hPa</Text>
            </View>

            <View style={styles.verticalDivider} />

            <View style={styles.gridItem}>
              <Text style={styles.gridLabel}>Umidade</Text>
              <Text style={styles.gridValue}>{selectedPlace.humidity}%</Text>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  map: {
    flex: 1,
  },
  inputContainer: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 20 : 50, 
    left: 16,
    right: 16,
    zIndex: 10,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  inputWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 5,
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: 50,
    paddingHorizontal: 20,
    fontSize: 16,
    color: '#000',
  },
  loader: {
    marginRight: 15,
  },
  locationButton: {
    width: 50,
    height: 50,
    backgroundColor: '#ffffff',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 5,
  },
  suggestionsContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    marginTop: 8,
    maxHeight: 240,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 5,
    elevation: 4,
    overflow: 'hidden',
    width: '85%',
  },
  suggestionItem: {
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
    borderBottomColor: '#eff2f5',
  },
  suggestionText: {
    fontSize: 14,
    color: '#333333',
    lineHeight: 18,
  },
  weatherCard: {
    position: 'absolute',
    bottom: 0, 
    left: 0,
    right: 0,
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingTop: 8,
    paddingHorizontal: 16,
    paddingBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 6,
    zIndex: 9,
  },
  dragHandle: {
    width: 36,
    height: 4,
    backgroundColor: '#e0e0e0',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  headerTextContainer: {
    flex: 1,
    marginRight: 10,
  },
  placeName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#202124',
    letterSpacing: -0.2,
  },
  placeSubName: {
    fontSize: 13,
    color: '#70757a',
    marginTop: 2,
  },
  closeButton: {
    padding: 6,
    backgroundColor: '#f1f3f4',
    borderRadius: 16,
    width: 28,
    height: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    fontSize: 11,
    color: '#5f6368',
    fontWeight: 'bold',
  },
  divider: {
    height: 1,
    backgroundColor: '#e8eaed',
    marginBottom: 12,
  },
  mainWeatherSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  tempContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  mainTemp: {
    fontSize: 36,
    fontWeight: '300',
    color: '#202124',
    marginRight: 10,
  },
  weatherMeta: {
    justifyContent: 'center',
  },
  weatherCondition: {
    fontSize: 14,
    fontWeight: '600',
    color: '#202124',
  },
  weatherSubInfo: {
    fontSize: 11,
    color: '#70757a',
    marginTop: 1,
  },
  statusBadge: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 12,
  },
  statusBadgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  insightBox: {
    backgroundColor: '#f8f9fa',
    borderLeftWidth: 3,
    borderLeftColor: '#1a73e8',
    padding: 10,
    borderRadius: 4,
    marginBottom: 14,
  },
  insightTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#3c4043',
    marginBottom: 2,
  },
  insightText: {
    fontSize: 12,
    color: '#5f6368',
    lineHeight: 16,
  },
  weatherGrid: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    backgroundColor: '#f8f9fa',
    borderRadius: 10,
    paddingVertical: 10,
  },
  gridItem: {
    alignItems: 'center',
    flex: 1,
  },
  gridLabel: {
    fontSize: 10,
    color: '#70757a',
    marginBottom: 2,
    fontWeight: '500',
    textTransform: 'uppercase',
  },
  gridValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#3c4043',
  },
  verticalDivider: {
    width: 1,
    height: 24,
    backgroundColor: '#dadce0',
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
  loadingText: {
    marginLeft: 10,
    fontSize: 14,
    color: '#70757a',
  }
});